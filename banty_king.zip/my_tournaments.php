<?php
include 'common/config.php';
if(!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); }
$uid = $_SESSION['user_id'];
?>
<?php include 'common/header.php'; ?>

<!-- Auto Refresh for Live Updates -->
<meta http-equiv="refresh" content="30">

<div class="p-4 mb-24">
    <h2 class="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 to-yellow-600 mb-6 uppercase tracking-wide">My Lobby</h2>

    <?php
    $sql = "SELECT t.*, p.id as pid FROM tournaments t 
            JOIN participants p ON t.id = p.tournament_id 
            WHERE p.user_id = $uid AND (t.status = 'upcoming' OR t.status = 'live') 
            ORDER BY t.match_time ASC";
    $res = $conn->query($sql);
    ?>

    <div class="space-y-6">
        <?php while($row = $res->fetch_assoc()): ?>
            <?php 
                $img = !empty($row['image_url']) ? $row['image_url'] : 'https://placehold.co/600x300/1a1a1a/gold?text=Game';
                $is_live = ($row['status'] == 'live' && !empty($row['room_id']));

                // --- 🎮 GAME LAUNCH LOGIC ---
                $game_link = "#";
                $game_name = strtolower($row['game_name']); // Convert to lowercase for checking

                if(strpos($game_name, 'bgmi') !== false) {
                    // BGMI Intent
                    $game_link = "intent://#Intent;package=com.pubg.imobile;scheme=bgmi;end";
                } elseif(strpos($game_name, 'free fire') !== false) {
                    // Free Fire Max Intent
                    $game_link = "intent://#Intent;package=com.dts.freefiremax;scheme=ffmax;end";
                } else {
                    // Default Fallback (Just in case)
                    $game_link = "#";
                }
            ?>
            
            <div class="bg-gray-900 rounded-2xl overflow-hidden border border-yellow-500/20 shadow-lg relative">
                <!-- Status Badge -->
                <div class="absolute top-3 left-3 z-10">
                    <?php if($row['status'] == 'live'): ?>
                        <span class="bg-red-600 text-white text-[10px] font-bold px-3 py-1 rounded-full animate-pulse shadow-[0_0_10px_red]">LIVE NOW</span>
                    <?php else: ?>
                        <span class="bg-blue-600/80 backdrop-blur text-white text-[10px] font-bold px-3 py-1 rounded-full">UPCOMING</span>
                    <?php endif; ?>
                </div>

                <!-- Banner -->
                <div class="h-32 bg-cover bg-center" style="background-image: url('<?php echo $img; ?>'); opacity: 0.8;"></div>

                <div class="p-5">
                    <h3 class="text-white font-bold text-lg mb-2"><?php echo htmlspecialchars($row['title']); ?></h3>
                    
                    <?php if($is_live): ?>
                        <!-- LUXURY POPUP FOR ROOM ID -->
                        <div class="bg-gradient-to-b from-gray-800 to-gray-900 border border-yellow-500/50 p-4 rounded-xl shadow-[0_0_20px_rgba(234,179,8,0.1)] relative overflow-hidden animate-slide-up">
                            <div class="absolute -top-10 -right-10 bg-yellow-500/10 w-24 h-24 rounded-full blur-xl animate-pulse"></div>
                            
                            <p class="text-center text-yellow-400 font-bold text-sm mb-3 tracking-widest uppercase"><i class="fa-solid fa-key"></i> Room Access</p>
                            
                            <!-- Room ID -->
                            <div class="flex items-center justify-between bg-black/50 p-3 rounded mb-2 border border-gray-700">
                                <span class="text-gray-400 text-xs uppercase">Room ID</span>
                                <div class="flex items-center gap-2">
                                    <span class="text-white font-mono font-bold select-all"><?php echo $row['room_id']; ?></span>
                                    <button onclick="navigator.clipboard.writeText('<?php echo $row['room_id']; ?>')" class="text-yellow-500 hover:text-white"><i class="fa-regular fa-copy"></i></button>
                                </div>
                            </div>
                            
                            <!-- Password -->
                            <div class="flex items-center justify-between bg-black/50 p-3 rounded border border-gray-700 mb-4">
                                <span class="text-gray-400 text-xs uppercase">Password</span>
                                <div class="flex items-center gap-2">
                                    <span class="text-white font-mono font-bold select-all"><?php echo $row['room_password']; ?></span>
                                    <button onclick="navigator.clipboard.writeText('<?php echo $row['room_password']; ?>')" class="text-yellow-500 hover:text-white"><i class="fa-regular fa-copy"></i></button>
                                </div>
                            </div>

                            <!-- OPEN GAME BUTTON (DYNAMIC) -->
                            <button onclick="window.location.href='<?php echo $game_link; ?>'" class="w-full bg-green-600 text-white py-3 rounded-lg font-bold text-sm uppercase tracking-wide hover:bg-green-500 transition shadow-[0_0_15px_rgba(34,197,94,0.4)] flex justify-center items-center gap-2">
                                <i class="fa-solid fa-gamepad"></i> Open Game
                            </button>
                            
                        </div>
                    <?php else: ?>
                        <div class="flex justify-between items-center text-sm text-gray-400">
                            <span><i class="fa-regular fa-clock text-yellow-500"></i> <?php echo date("d M, h:i A", strtotime($row['match_time'])); ?></span>
                            <span class="italic text-xs">Waiting for Host...</span>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endwhile; ?>
        <?php if($res->num_rows == 0) echo "<p class='text-center text-gray-500 mt-10 opacity-50'>You haven't joined any active matches.</p>"; ?>
    </div>
</div>

<style>
    @keyframes slideUp { from { transform: translateY(10px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
    .animate-slide-up { animation: slideUp 0.5s ease-out; }
</style>

<?php include 'common/bottom.php'; ?>