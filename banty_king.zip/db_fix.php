<?php
$host = "127.0.0.1";
$user = "root";
$pass = "root"; // CHANGE THIS IF NEEDED
$db   = "banty_king_db";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error); }

echo "<h2>Analyzing Database...</h2>";

// 1. Fix Users Table (Add Avatar)
$check = $conn->query("SHOW COLUMNS FROM users LIKE 'avatar'");
if($check->num_rows == 0) {
    $conn->query("ALTER TABLE users ADD COLUMN avatar VARCHAR(255) DEFAULT 'https://api.dicebear.com/7.x/avataaars/svg?seed=Felix'");
    echo "✅ Added 'avatar' column to Users.<br>";
}

// 2. Fix Tournaments Table (Add Image URL)
$check = $conn->query("SHOW COLUMNS FROM tournaments LIKE 'image_url'");
if($check->num_rows == 0) {
    $conn->query("ALTER TABLE tournaments ADD COLUMN image_url VARCHAR(255) DEFAULT NULL");
    echo "✅ Added 'image_url' column to Tournaments.<br>";
}

// 3. Fix Transactions Table (Add Proof ID and Status)
$check = $conn->query("SHOW COLUMNS FROM transactions LIKE 'status'");
if($check->num_rows == 0) {
    $conn->query("ALTER TABLE transactions ADD COLUMN status ENUM('pending', 'success', 'failed') DEFAULT 'success'");
    echo "✅ Added 'status' column to Transactions.<br>";
}
$check = $conn->query("SHOW COLUMNS FROM transactions LIKE 'proof_id'");
if($check->num_rows == 0) {
    $conn->query("ALTER TABLE transactions ADD COLUMN proof_id VARCHAR(100) DEFAULT NULL");
    echo "✅ Added 'proof_id' column to Transactions.<br>";
}

echo "<h3>🎉 Database Fixed Successfully! You can now use the Admin Panel.</h3>";
echo "<a href='admin/index.php'>Go to Admin Panel</a>";
?>