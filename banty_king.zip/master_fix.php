<?php
include 'common/config.php';

echo "<h1>🛠️ Banty King: Master Database Repair</h1>";
echo "<div style='background:#f4f4f4; padding:20px; border:1px solid #ddd;'>";

// 1. FIX TRANSACTIONS TABLE (Fixes the "Unknown column 'status'" error)
$check = $conn->query("SHOW COLUMNS FROM transactions LIKE 'status'");
if($check->num_rows == 0) {
    $conn->query("ALTER TABLE transactions ADD COLUMN status ENUM('pending', 'success', 'failed') DEFAULT 'success'");
    echo "<p style='color:green'>✅ Added 'status' column to transactions.</p>";
}
$check = $conn->query("SHOW COLUMNS FROM transactions LIKE 'proof_id'");
if($check->num_rows == 0) {
    $conn->query("ALTER TABLE transactions ADD COLUMN proof_id VARCHAR(100) DEFAULT NULL");
    echo "<p style='color:green'>✅ Added 'proof_id' column to transactions.</p>";
}

// 2. FIX TOURNAMENTS TABLE (Fixes the Tournament Create Error)
$cols = [
    'image_url' => "VARCHAR(255) DEFAULT NULL",
    'icon_url' => "VARCHAR(255) DEFAULT NULL",
    'map_type' => "VARCHAR(50) DEFAULT 'Erangel'",
    'max_players' => "INT DEFAULT 100"
];

foreach($cols as $col => $def) {
    $check = $conn->query("SHOW COLUMNS FROM tournaments LIKE '$col'");
    if($check->num_rows == 0) {
        $conn->query("ALTER TABLE tournaments ADD COLUMN $col $def");
        echo "<p style='color:green'>✅ Added '$col' column to tournaments.</p>";
    }
}

// 3. FIX USERS TABLE
$check = $conn->query("SHOW COLUMNS FROM users LIKE 'avatar'");
if($check->num_rows == 0) {
    $conn->query("ALTER TABLE users ADD COLUMN avatar VARCHAR(255) DEFAULT NULL");
    echo "<p style='color:green'>✅ Added 'avatar' column to users.</p>";
}

echo "</div>";
echo "<h2>🎉 Database is Fully Repaired!</h2>";
echo "<a href='admin/index.php' style='background:blue; color:white; padding:10px 20px; text-decoration:none; border-radius:5px;'>Go to Admin Panel</a>";
?>