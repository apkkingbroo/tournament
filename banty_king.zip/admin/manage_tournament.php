<?php
include 'common/header.php';
$tid = isset($_GET['id']) ? intval($_GET['id']) : 0;
if($tid == 0) header("Location: tournament.php");

$msg = "";

// UPDATE ROOM & GO LIVE
if(isset($_POST['go_live'])) {
    $rid = $_POST['room_id'];
    $pass = $_POST['room_pass'];
    // Setting status to 'live' triggers the popup in user app
    $conn->query("UPDATE tournaments SET room_id='$rid', room_password='$pass', status='live' WHERE id=$tid");
    $msg = "<p class='bg-green-100 text-green-700 p-2 rounded'>✅ Match is LIVE! Users can see Room ID.</p>";
}

// STOP MATCH (Reset to upcoming if mistake)
if(isset($_POST['stop_live'])) {
    $conn->query("UPDATE tournaments SET status='upcoming' WHERE id=$tid");
    $msg = "<p class='bg-yellow-100 text-yellow-700 p-2 rounded'>Match status reverted to Upcoming.</p>";
}

$t = $conn->query("SELECT * FROM tournaments WHERE id=$tid")->fetch_assoc();
?>

<div class="p-4 mb-20">
    <a href="tournament.php" class="text-gray-500 mb-4 inline-block">&larr; Back</a>
    <h2 class="text-xl font-bold"><?php echo $t['title']; ?></h2>
    <span class="bg-gray-200 px-2 py-1 rounded text-xs font-bold"><?php echo strtoupper($t['status']); ?></span>
    
    <?php echo $msg; ?>

    <div class="bg-white p-5 rounded shadow mt-4 border border-indigo-100">
        <h3 class="font-bold text-gray-700 mb-3">Room Configuration</h3>
        <form method="POST" class="grid gap-3">
            <input type="text" name="room_id" value="<?php echo $t['room_id']; ?>" placeholder="Room ID" class="border p-2 rounded">
            <input type="text" name="room_pass" value="<?php echo $t['room_password']; ?>" placeholder="Password" class="border p-2 rounded">
            
            <?php if($t['status'] != 'live'): ?>
                <button type="submit" name="go_live" class="bg-red-600 text-white font-bold py-3 rounded shadow hover:bg-red-700">
                    <i class="fa-solid fa-broadcast-tower"></i> SAVE & GO LIVE
                </button>
            <?php else: ?>
                <button type="submit" name="go_live" class="bg-green-600 text-white font-bold py-3 rounded shadow">
                    UPDATE DETAILS
                </button>
                <button type="submit" name="stop_live" class="bg-gray-500 text-white text-xs py-2 rounded">
                    Stop Live Status
                </button>
            <?php endif; ?>
        </form>
    </div>
</div>
<?php include 'common/bottom.php'; ?>