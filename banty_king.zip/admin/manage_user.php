<?php
include 'common/header.php';

$uid = isset($_GET['id']) ? intval($_GET['id']) : 0;
if($uid == 0) { header("Location: user.php"); exit(); }

$msg = "";

// --- HANDLE MONEY UPDATE ---
if(isset($_POST['update_balance'])) {
    $amount = abs(floatval($_POST['amount']));
    $action = $_POST['action']; // 'credit' or 'debit'
    $note = sanitize($conn, $_POST['note']);

    if($amount > 0 && !empty($note)) {
        $conn->begin_transaction();
        try {
            if($action == 'credit') {
                // Add Money
                $conn->query("UPDATE users SET wallet_balance = wallet_balance + $amount WHERE id = $uid");
                $type = 'credit';
                $desc = "Admin Credit: " . $note;
            } else {
                // Deduct Money
                $conn->query("UPDATE users SET wallet_balance = wallet_balance - $amount WHERE id = $uid");
                $type = 'debit';
                $desc = "Admin Debit: " . $note;
            }

            // FIXED QUERY: Explicitly includes 'status'
            $stmt = $conn->prepare("INSERT INTO transactions (user_id, amount, type, description, status, created_at) VALUES (?, ?, ?, ?, 'success', NOW())");
            
            if(!$stmt) {
                throw new Exception("SQL Prepare Failed: " . $conn->error);
            }

            $stmt->bind_param("idss", $uid, $amount, $type, $desc);
            
            if(!$stmt->execute()) {
                throw new Exception("SQL Execute Failed: " . $stmt->error);
            }

            $conn->commit();
            $msg = "<div class='bg-green-100 text-green-700 p-3 rounded mb-4 border-l-4 border-green-500'>Success! Wallet updated.</div>";
        } catch(Exception $e) {
            $conn->rollback();
            $msg = "<div class='bg-red-100 text-red-700 p-3 rounded mb-4'>Error: " . $e->getMessage() . "</div>";
        }
    } else {
        $msg = "<div class='bg-red-100 text-red-700 p-3 rounded mb-4'>Please enter amount and reason.</div>";
    }
}

// Fetch User Data
$u = $conn->query("SELECT * FROM users WHERE id = $uid")->fetch_assoc();
if(!$u) { die("<div class='p-4'>User not found. <a href='user.php'>Back</a></div>"); }

// Fetch Stats
$trans = $conn->query("SELECT * FROM transactions WHERE user_id=$uid ORDER BY id DESC LIMIT 10");
?>

<div class="p-4 mb-20 bg-gray-50 min-h-screen">
    <a href="user.php" class="inline-flex items-center text-gray-500 text-sm mb-4 hover:text-indigo-600 font-bold">
        <i class="fa-solid fa-arrow-left mr-2"></i> Back to User List
    </a>

    <!-- User Profile Card -->
    <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-200 mb-6 flex items-center gap-4">
        <div class="w-16 h-16 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 font-bold text-2xl">
            <?php echo strtoupper(substr($u['username'], 0, 1)); ?>
        </div>
        <div>
            <h1 class="text-xl font-bold text-gray-800"><?php echo htmlspecialchars($u['username']); ?></h1>
            <p class="text-gray-500 text-sm"><?php echo $u['email']; ?></p>
            <p class="text-2xl font-bold text-green-600 mt-1">₹<?php echo number_format($u['wallet_balance'], 2); ?></p>
        </div>
    </div>

    <?php echo $msg; ?>

    <!-- MANAGE WALLET FORM -->
    <div class="bg-white p-6 rounded-xl shadow-sm border border-gray-200 mb-6">
        <h3 class="font-bold text-gray-800 mb-4 flex items-center gap-2 border-b pb-2">
            <i class="fa-solid fa-coins text-yellow-500"></i> Manage Funds
        </h3>
        
        <form method="POST" class="space-y-4">
            <div>
                <label class="block text-xs font-bold text-gray-500 mb-2 uppercase">Select Action</label>
                <div class="grid grid-cols-2 gap-4">
                    <!-- Credit Option -->
                    <div class="relative">
                        <input type="radio" name="action" id="act_credit" value="credit" checked class="peer sr-only">
                        <label for="act_credit" class="block cursor-pointer p-3 rounded-lg border-2 border-gray-200 bg-gray-50 hover:bg-green-50 peer-checked:border-green-500 peer-checked:bg-green-50 peer-checked:text-green-800 transition text-center h-full flex flex-col items-center justify-center">
                            <i class="fa-solid fa-circle-plus text-2xl mb-1"></i>
                            <span class="font-bold text-sm">Add Money</span>
                        </label>
                    </div>

                    <!-- Debit Option -->
                    <div class="relative">
                        <input type="radio" name="action" id="act_debit" value="debit" class="peer sr-only">
                        <label for="act_debit" class="block cursor-pointer p-3 rounded-lg border-2 border-gray-200 bg-gray-50 hover:bg-red-50 peer-checked:border-red-500 peer-checked:bg-red-50 peer-checked:text-red-800 transition text-center h-full flex flex-col items-center justify-center">
                            <i class="fa-solid fa-circle-minus text-2xl mb-1"></i>
                            <span class="font-bold text-sm">Deduct Money</span>
                        </label>
                    </div>
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-xs font-bold text-gray-500 mb-1 uppercase">Amount (₹)</label>
                    <input type="number" name="amount" placeholder="0" required class="w-full border-2 border-gray-200 p-3 rounded-lg text-lg font-bold outline-none focus:border-indigo-500 transition">
                </div>
                <div>
                    <label class="block text-xs font-bold text-gray-500 mb-1 uppercase">Reason</label>
                    <input type="text" name="note" placeholder="e.g. Winning Adjustment" required class="w-full border-2 border-gray-200 p-3 rounded-lg outline-none focus:border-indigo-500 transition">
                </div>
            </div>

            <button type="submit" name="update_balance" class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 rounded-lg shadow-lg text-lg transition transform active:scale-[0.98]">
                Process Transaction
            </button>
        </form>
    </div>

    <!-- Recent History -->
    <h3 class="font-bold text-gray-600 mb-3 text-sm uppercase px-1">Recent Activity</h3>
    <div class="space-y-2">
        <?php while($t = $trans->fetch_assoc()): ?>
            <div class="bg-white p-3 rounded-lg border border-gray-200 flex justify-between items-center text-sm shadow-sm">
                <div>
                    <p class="font-bold text-gray-800"><?php echo htmlspecialchars($t['description']); ?></p>
                    <p class="text-[10px] text-gray-400"><?php echo date("d M, h:i A", strtotime($t['created_at'])); ?></p>
                </div>
                <span class="font-bold <?php echo ($t['type']=='credit')?'text-green-600':'text-red-600'; ?>">
                    <?php echo ($t['type']=='credit')?'+':'-'; ?>₹<?php echo $t['amount']; ?>
                </span>
            </div>
        <?php endwhile; ?>
    </div>

</div>

<?php include 'common/bottom.php'; ?>