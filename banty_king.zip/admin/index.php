<?php 
include 'common/header.php'; 

// Helper function to prevent Fatal Errors if DB is messy
function get_stat($conn, $sql) {
    $result = $conn->query($sql);
    if($result) {
        $row = $result->fetch_assoc();
        return $row['c'] ?? 0;
    }
    return 0; // Return 0 if query fails
}

// Stats Logic (Crash Proof)
$users = get_stat($conn, "SELECT count(*) as c FROM users");
$tourn = get_stat($conn, "SELECT count(*) as c FROM tournaments");
$pending_dep = get_stat($conn, "SELECT count(*) as c FROM transactions WHERE type='credit' AND status='pending'");
$pending_wit = get_stat($conn, "SELECT count(*) as c FROM transactions WHERE type='debit' AND status='pending' AND description LIKE 'Withdraw%'");
?>

<div class="p-4 mb-16">
    <h2 class="text-xl font-bold text-gray-800 mb-4">Dashboard</h2>
    
    <!-- Stats Grid -->
    <div class="grid grid-cols-2 gap-4 mb-6">
        <div class="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
            <div class="text-gray-400 text-xs font-bold uppercase mb-1">Total Users</div>
            <div class="text-2xl font-bold text-gray-800"><?php echo $users; ?></div>
        </div>
        <div class="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
            <div class="text-gray-400 text-xs font-bold uppercase mb-1">Matches</div>
            <div class="text-2xl font-bold text-indigo-600"><?php echo $tourn; ?></div>
        </div>
        <div class="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
            <div class="text-gray-400 text-xs font-bold uppercase mb-1">Pending Dep</div>
            <div class="text-2xl font-bold text-green-600"><?php echo $pending_dep; ?></div>
        </div>
        <div class="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
            <div class="text-gray-400 text-xs font-bold uppercase mb-1">Withdrawals</div>
            <div class="text-2xl font-bold text-red-600"><?php echo $pending_wit; ?></div>
        </div>
    </div>

    <!-- Quick Actions -->
    <h3 class="text-sm font-bold text-gray-500 uppercase mb-3">Quick Actions</h3>
    
    <a href="tournament.php" class="flex items-center gap-3 bg-white p-4 rounded-xl shadow-sm border border-gray-100 mb-3 hover:bg-gray-50 transition">
        <div class="w-10 h-10 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center">
            <i class="fa-solid fa-plus"></i>
        </div>
        <div>
            <div class="font-bold text-gray-800">Create New Match</div>
            <div class="text-xs text-gray-500">Add BGMI or FreeFire tournament</div>
        </div>
    </a>

    <div class="grid grid-cols-2 gap-3 mb-6">
        <a href="deposits.php" class="bg-green-50 p-4 rounded-xl border border-green-100 text-center hover:bg-green-100 transition">
            <i class="fa-solid fa-money-bill-transfer text-green-600 text-xl mb-1"></i>
            <div class="text-xs font-bold text-green-700">Verify Deposits</div>
        </a>
        <a href="withdrawals.php" class="bg-red-50 p-4 rounded-xl border border-red-100 text-center hover:bg-red-100 transition">
            <i class="fa-solid fa-hand-holding-dollar text-red-600 text-xl mb-1"></i>
            <div class="text-xs font-bold text-red-700">Pay Withdrawals</div>
        </a>
    </div>

</div>

<?php include 'common/bottom.php'; ?>