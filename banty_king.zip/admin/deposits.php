<?php
include 'common/header.php';
$msg = "";

// --- HANDLE ACTIONS ---
if(isset($_POST['action'])) {
    $tid = intval($_POST['txn_id']);
    $uid = intval($_POST['user_id']);
    $amt = floatval($_POST['amount']);
    $act = $_POST['action'];

    // Check if transaction is still pending to avoid double credit
    $chk = $conn->query("SELECT status FROM transactions WHERE id=$tid");
    if($chk && $chk->num_rows > 0) {
        $status = $chk->fetch_assoc()['status'];
        
        if($status == 'pending') {
            if($act == 'approve') {
                // START TRANSACTION
                $conn->begin_transaction();
                try {
                    // 1. Add Money to User
                    $u_upd = $conn->query("UPDATE users SET wallet_balance = wallet_balance + $amt WHERE id = $uid");
                    
                    // 2. Mark Transaction Success
                    $t_upd = $conn->query("UPDATE transactions SET status = 'success' WHERE id = $tid");

                    if($u_upd && $t_upd) {
                        $conn->commit();
                        $msg = "<div class='bg-green-100 text-green-700 p-3 rounded mb-4'>✅ Deposit Approved & ₹$amt Credited!</div>";
                    } else {
                        throw new Exception("Database Update Failed");
                    }
                } catch(Exception $e) {
                    $conn->rollback();
                    $msg = "<div class='bg-red-100 text-red-700 p-3 rounded mb-4'>Error: " . $e->getMessage() . "</div>";
                }
            } elseif($act == 'reject') {
                // Just mark failed
                $conn->query("UPDATE transactions SET status = 'failed' WHERE id = $tid");
                $msg = "<div class='bg-red-100 text-red-700 p-3 rounded mb-4'>❌ Deposit Rejected.</div>";
            }
        } else {
            $msg = "<div class='bg-yellow-100 text-yellow-700 p-3 rounded mb-4'>⚠️ Transaction already processed.</div>";
        }
    }
}

// Fetch Pending Deposits
$sql = "SELECT t.*, u.username, u.email FROM transactions t 
        JOIN users u ON t.user_id = u.id 
        WHERE t.type='credit' AND t.status='pending' 
        ORDER BY t.created_at ASC";
$result = $conn->query($sql);
?>

<div class="p-4 mb-20">
    <h2 class="text-xl font-bold mb-4 text-gray-800">Verify Deposits</h2>
    <?php echo $msg; ?>

    <div class="space-y-4">
        <?php if($result && $result->num_rows > 0): ?>
            <?php while($row = $result->fetch_assoc()): ?>
                <div class="bg-white p-4 rounded-lg shadow-sm border-l-4 border-green-500">
                    <div class="flex justify-between items-start mb-2">
                        <div>
                            <span class="bg-gray-100 text-gray-600 text-[10px] px-2 py-1 rounded font-bold uppercase">
                                <?php echo htmlspecialchars($row['username']); ?>
                            </span>
                            <h3 class="text-2xl font-bold text-green-600 mt-1">+₹<?php echo number_format($row['amount'], 2); ?></h3>
                        </div>
                        <span class="text-[10px] text-gray-400"><?php echo date("d M, h:i A", strtotime($row['created_at'])); ?></span>
                    </div>

                    <div class="bg-gray-50 p-3 rounded border border-gray-200 mb-3">
                        <p class="text-xs text-gray-500 font-bold uppercase">UTR / Ref No:</p>
                        <p class="text-lg font-mono font-bold text-gray-800 select-all tracking-wide"><?php echo htmlspecialchars($row['proof_id']); ?></p>
                    </div>

                    <form method="POST" class="flex gap-3">
                        <input type="hidden" name="txn_id" value="<?php echo $row['id']; ?>">
                        <input type="hidden" name="user_id" value="<?php echo $row['user_id']; ?>">
                        <input type="hidden" name="amount" value="<?php echo $row['amount']; ?>">
                        
                        <button type="submit" name="action" value="approve" class="flex-1 bg-green-600 text-white py-2 rounded font-bold shadow hover:bg-green-700">
                            Approve
                        </button>
                        <button type="submit" name="action" value="reject" class="flex-1 bg-red-50 text-red-600 py-2 rounded font-bold border border-red-200 hover:bg-red-100">
                            Reject
                        </button>
                    </form>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="text-center py-10 bg-white rounded shadow text-gray-400">
                <i class="fa-solid fa-check-circle text-4xl mb-2"></i>
                <p>No pending deposits.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php include 'common/bottom.php'; ?>