<?php 
$cur = basename($_SERVER['PHP_SELF']); 
?>
<?php if($cur != 'login.php'): ?>
<div class="fixed bottom-0 w-full bg-white border-t border-gray-200 z-50 flex justify-around py-2 shadow-[0_-5px_15px_rgba(0,0,0,0.05)]">
    
    <a href="index.php" class="flex flex-col items-center w-16 group">
        <i class="fa-solid fa-chart-pie text-xl mb-1 transition <?php echo ($cur=='index.php')?'text-indigo-600':'text-gray-400 group-hover:text-gray-600'; ?>"></i>
        <span class="text-[10px] font-bold <?php echo ($cur=='index.php')?'text-indigo-600':'text-gray-500'; ?>">Dash</span>
    </a>

    <a href="tournament.php" class="flex flex-col items-center w-16 group">
        <i class="fa-solid fa-trophy text-xl mb-1 transition <?php echo ($cur=='tournament.php' || $cur=='manage_tournament.php')?'text-indigo-600':'text-gray-400 group-hover:text-gray-600'; ?>"></i>
        <span class="text-[10px] font-bold <?php echo ($cur=='tournament.php' || $cur=='manage_tournament.php')?'text-indigo-600':'text-gray-500'; ?>">Matches</span>
    </a>

    <a href="deposits.php" class="flex flex-col items-center w-16 group">
        <div class="relative">
            <i class="fa-solid fa-wallet text-xl mb-1 transition <?php echo ($cur=='deposits.php')?'text-indigo-600':'text-gray-400 group-hover:text-gray-600'; ?>"></i>
            <!-- Optional: Notification Dot logic could go here -->
        </div>
        <span class="text-[10px] font-bold <?php echo ($cur=='deposits.php')?'text-indigo-600':'text-gray-500'; ?>">Deposits</span>
    </a>

    <a href="user.php" class="flex flex-col items-center w-16 group">
        <i class="fa-solid fa-users text-xl mb-1 transition <?php echo ($cur=='user.php' || $cur=='manage_user.php')?'text-indigo-600':'text-gray-400 group-hover:text-gray-600'; ?>"></i>
        <span class="text-[10px] font-bold <?php echo ($cur=='user.php' || $cur=='manage_user.php')?'text-indigo-600':'text-gray-500'; ?>">Users</span>
    </a>

</div>
<?php endif; ?>
</body>
</html>