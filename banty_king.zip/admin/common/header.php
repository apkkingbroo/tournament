<?php
// Fix Path: Go up 2 levels (admin/common/ -> admin/ -> root/) to find common/config.php
if(!isset($conn)) { 
    if(file_exists(__DIR__ . '/../../common/config.php')) {
        include __DIR__ . '/../../common/config.php';
    } else {
        die("Error: Cannot find config.php. Please check file structure.");
    }
}

// Admin Security Check
$cur_page = basename($_SERVER['PHP_SELF']);
if(!isset($_SESSION['admin_id']) && $cur_page != 'login.php') {
    header("Location: login.php"); exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Banty King</title>
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background-color: #f3f4f6; color: #1f2937; }
        /* Admin Scrollbar */
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: #f1f1f1; }
        ::-webkit-scrollbar-thumb { background: #888; border-radius: 3px; }
        ::-webkit-scrollbar-thumb:hover { background: #555; }
    </style>
</head>
<body class="pb-20">

<?php if($cur_page != 'login.php'): ?>
<!-- Admin Top Bar -->
<nav class="bg-white px-4 py-3 shadow-sm border-b border-gray-200 sticky top-0 z-50 flex justify-between items-center">
    <div class="flex items-center gap-2">
        <div class="bg-indigo-600 text-white w-8 h-8 rounded flex items-center justify-center font-bold">A</div>
        <h1 class="font-bold text-gray-800 tracking-tight">Admin<span class="text-indigo-600">Panel</span></h1>
    </div>
    <a href="setting.php" class="text-gray-400 hover:text-indigo-600 transition"><i class="fa-solid fa-gear"></i></a>
</nav>
<?php endif; ?>