<?php
include 'common/header.php';
$msg = "";
$aid = $_SESSION['admin_id'];

if(isset($_POST['change_pass'])) {
    $pass = $_POST['password'];
    $hash = password_hash($pass, PASSWORD_DEFAULT);
    $conn->query("UPDATE admin SET password='$hash' WHERE id=$aid");
    $msg = "Password Updated";
}

if(isset($_POST['logout'])) {
    session_destroy();
    header("Location: login.php"); exit();
}
?>

<div class="p-4">
    <h2 class="text-xl font-bold mb-4">Settings</h2>
    <?php if($msg) echo "<p class='text-green-500 mb-2'>$msg</p>"; ?>
    
    <div class="bg-white p-4 rounded shadow mb-4">
        <h3 class="font-bold mb-3">Change Password</h3>
        <form method="POST">
            <input type="password" name="password" placeholder="New Password" class="border p-2 rounded w-full mb-2">
            <button type="submit" name="change_pass" class="bg-indigo-600 text-white px-4 py-2 rounded">Update</button>
        </form>
    </div>

    <form method="POST">
        <button type="submit" name="logout" class="bg-red-500 text-white w-full py-3 rounded font-bold">Logout</button>
    </form>
</div>

<?php include 'common/bottom.php'; ?>