<?php
include 'common/header.php';

// Search Logic
$search = "";
$sql = "SELECT * FROM users ORDER BY id DESC";
if(isset($_GET['search'])) {
    $search = sanitize($conn, $_GET['search']);
    $sql = "SELECT * FROM users WHERE username LIKE '%$search%' OR email LIKE '%$search%' ORDER BY id DESC";
}

$users = $conn->query($sql);
$total_users = $users->num_rows;
?>

<div class="p-4 mb-20">
    <!-- Header & Search -->
    <div class="flex justify-between items-end mb-4">
        <div>
            <h2 class="text-xl font-bold text-gray-800">User Management</h2>
            <p class="text-xs text-gray-500">Total Users: <?php echo $total_users; ?></p>
        </div>
    </div>

    <!-- Search Bar -->
    <form method="GET" class="mb-6 relative">
        <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search by username or email..." class="w-full pl-10 pr-4 py-3 rounded-lg border border-gray-300 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none shadow-sm transition">
        <i class="fa-solid fa-magnifying-glass absolute left-3 top-3.5 text-gray-400"></i>
        <?php if($search): ?>
            <a href="user.php" class="absolute right-3 top-3.5 text-red-500 text-xs font-bold">CLEAR</a>
        <?php endif; ?>
    </form>

    <!-- User List -->
    <div class="space-y-3">
        <?php if($users->num_rows > 0): ?>
            <?php while($u = $users->fetch_assoc()): ?>
                <div class="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex justify-between items-center hover:shadow-md transition">
                    <div class="flex items-center gap-3">
                        <!-- Avatar Placeholder -->
                        <div class="w-12 h-12 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white font-bold text-lg shadow">
                            <?php echo strtoupper(substr($u['username'], 0, 1)); ?>
                        </div>
                        <div>
                            <h4 class="font-bold text-gray-800"><?php echo htmlspecialchars($u['username']); ?></h4>
                            <p class="text-xs text-gray-500"><?php echo $u['email']; ?></p>
                            <span class="text-[10px] bg-gray-100 px-2 py-0.5 rounded text-gray-600">ID: <?php echo $u['id']; ?></span>
                        </div>
                    </div>
                    
                    <div class="text-right">
                        <p class="font-bold text-green-600 text-lg">₹<?php echo number_format($u['wallet_balance'], 2); ?></p>
                        <a href="manage_user.php?id=<?php echo $u['id']; ?>" class="inline-block mt-1 bg-indigo-50 text-indigo-600 text-xs font-bold px-3 py-1.5 rounded border border-indigo-100 hover:bg-indigo-100">
                            Manage
                        </a>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="text-center py-10 text-gray-400">
                <i class="fa-solid fa-user-slash text-4xl mb-2"></i>
                <p>No users found.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php include 'common/bottom.php'; ?>