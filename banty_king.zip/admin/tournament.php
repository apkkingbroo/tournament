<?php
include 'common/header.php';
$msg = "";

if(isset($_POST['add_tournament'])) {
    // 1. Sanitize Inputs
    $title = sanitize($conn, $_POST['title']);
    $game = sanitize($conn, $_POST['game']);
    $map = sanitize($conn, $_POST['map']); 
    $fee = floatval($_POST['fee']);
    $prize = floatval($_POST['prize']);
    $slots = intval($_POST['slots']);
    
    // Fix Time Format (HTML gives 'Y-m-dTH:i', DB needs 'Y-m-d H:i')
    $time = str_replace("T", " ", $_POST['time']);
    
    $custom_icon = sanitize($conn, $_POST['icon_url']); 

    // Default Images
    $img_url = "https://placehold.co/600x300?text=Game";
    if($game == "BGMI") $img_url = "https://files.catbox.moe/jgk4ws.jpg";
    elseif($game == "Free Fire Max") $img_url = "https://files.catbox.moe/1c5etj.jpg";

    // 2. Prepare Statement
    $query = "INSERT INTO tournaments (title, game_name, map_type, entry_fee, prize_pool, match_time, image_url, icon_url, max_players) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    $stmt = $conn->prepare($query);
    
    if(!$stmt) {
        // ERROR CATCHER: If this shows, run master_fix.php
        $msg = "<p class='bg-red-100 p-2 text-red-700 rounded'><b>SQL Error:</b> " . $conn->error . "<br>Please run <b>master_fix.php</b></p>";
    } else {
        $stmt->bind_param("sssddsssi", $title, $game, $map, $fee, $prize, $time, $img_url, $custom_icon, $slots);
        
        if($stmt->execute()) {
            $msg = "<p class='bg-green-100 p-2 text-green-700 rounded'>✅ Match Created Successfully!</p>";
        } else {
            $msg = "<p class='bg-red-100 p-2 text-red-700 rounded'>Error: ".$stmt->error."</p>";
        }
    }
}

// Fetch List
$list = $conn->query("SELECT * FROM tournaments ORDER BY id DESC LIMIT 20");
?>

<div class="p-4 mb-20">
    <h2 class="text-xl font-bold mb-4 text-gray-800">Create Match</h2>
    <?php echo $msg; ?>
    
    <div class="bg-white p-5 rounded-lg shadow-md mb-6 border border-gray-100">
        <form method="POST" class="grid gap-4">
            <!-- Game & Map -->
            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="text-xs font-bold text-gray-500 mb-1 block">Select Game</label>
                    <select name="game" required class="border p-2 rounded w-full bg-white text-gray-700">
                        <option value="BGMI">BGMI</option>
                        <option value="Free Fire Max">Free Fire Max</option>
                    </select>
                </div>
                <div>
                    <label class="text-xs font-bold text-gray-500 mb-1 block">Map / Category</label>
                    <input type="text" name="map" placeholder="e.g. TDM, Erangel" required class="border p-2 rounded w-full">
                </div>
            </div>

            <div>
                <label class="text-xs font-bold text-gray-500 mb-1 block">Tournament Title</label>
                <input type="text" name="title" placeholder="e.g. Squad War #101" required class="border p-2 rounded w-full">
            </div>

            <!-- Square Icon URL -->
            <div>
                 <label class="text-xs font-bold text-gray-500 mb-1 block">Square Icon URL (Optional)</label>
                 <input type="text" name="icon_url" placeholder="Paste image link here for small icon" class="border p-2 rounded w-full">
            </div>

            <!-- Financials -->
            <div class="grid grid-cols-3 gap-2">
                <div>
                    <label class="text-xs font-bold text-gray-500 mb-1 block">Fee (₹)</label>
                    <input type="number" name="fee" placeholder="0" required class="border p-2 rounded w-full">
                </div>
                <div>
                    <label class="text-xs font-bold text-gray-500 mb-1 block">Prize (₹)</label>
                    <input type="number" name="prize" placeholder="0" required class="border p-2 rounded w-full">
                </div>
                <div>
                    <label class="text-xs font-bold text-gray-500 mb-1 block">Slots</label>
                    <input type="number" name="slots" placeholder="100" value="100" required class="border p-2 rounded w-full">
                </div>
            </div>

            <div>
                <label class="text-xs font-bold text-gray-500 mb-1 block">Match Time</label>
                <input type="datetime-local" name="time" required class="border p-2 rounded w-full">
            </div>
            
            <button type="submit" name="add_tournament" class="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-3 rounded-lg font-bold shadow transition">
                Create Tournament
            </button>
        </form>
    </div>

    <!-- List -->
    <h3 class="font-bold text-gray-600 mb-3 text-sm uppercase">Recent Matches</h3>
    <div class="space-y-3">
        <?php while($row = $list->fetch_assoc()): ?>
            <div class="bg-white p-3 rounded-lg shadow-sm flex justify-between items-center border border-gray-200">
                <div class="flex items-center gap-3">
                    <?php if(!empty($row['icon_url'])): ?>
                        <img src="<?php echo $row['icon_url']; ?>" class="w-10 h-10 rounded object-cover border">
                    <?php endif; ?>
                    <div>
                        <h4 class="font-bold text-sm text-gray-800">#<?php echo $row['id']; ?> <?php echo htmlspecialchars($row['title']); ?></h4>
                        <p class="text-xs text-gray-500"><?php echo htmlspecialchars($row['map_type']); ?> | Slots: <?php echo $row['max_players']; ?></p>
                    </div>
                </div>
                <a href="manage_tournament.php?id=<?php echo $row['id']; ?>" class="bg-indigo-50 text-indigo-600 px-3 py-1 rounded text-xs font-bold border border-indigo-100">Manage</a>
            </div>
        <?php endwhile; ?>
    </div>
</div>
<?php include 'common/bottom.php'; ?>