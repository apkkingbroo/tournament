<?php
// Include Config relative to this file
include '../common/config.php';

if(isset($_SESSION['admin_id'])) { header("Location: index.php"); exit(); }

$msg = "";
if(isset($_POST['admin_login'])) {
    $username = sanitize($conn, $_POST['username']);
    $password = $_POST['password'];
    
    $res = $conn->query("SELECT * FROM admin WHERE username='$username'");
    if($res->num_rows > 0) {
        $row = $res->fetch_assoc();
        // Verify Password (Assuming hashed, but for initial install it was hashed in install.php)
        if(password_verify($password, $row['password'])) {
            $_SESSION['admin_id'] = $row['id'];
            header("Location: index.php"); exit();
        } else {
            $msg = "Incorrect Password";
        }
    } else {
        $msg = "Admin not found";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 h-screen flex items-center justify-center p-4">

    <div class="bg-white p-8 rounded-xl shadow-lg w-full max-w-sm border border-gray-200">
        <div class="text-center mb-6">
            <h2 class="text-2xl font-bold text-gray-800">Admin Login</h2>
            <p class="text-gray-500 text-sm">Banty King Management</p>
        </div>

        <?php if($msg): ?>
            <div class="bg-red-100 text-red-600 text-sm p-3 rounded mb-4 text-center border border-red-200">
                <?php echo $msg; ?>
            </div>
        <?php endif; ?>

        <form method="POST" class="space-y-4">
            <div>
                <label class="block text-gray-600 text-xs font-bold mb-1">Username</label>
                <input type="text" name="username" required class="w-full border border-gray-300 p-3 rounded-lg focus:outline-none focus:border-indigo-500 transition">
            </div>
            <div>
                <label class="block text-gray-600 text-xs font-bold mb-1">Password</label>
                <input type="password" name="password" required class="w-full border border-gray-300 p-3 rounded-lg focus:outline-none focus:border-indigo-500 transition">
            </div>
            <button type="submit" name="admin_login" class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 rounded-lg transition shadow-md">
                Secure Login
            </button>
        </form>
        
        <div class="mt-4 text-center">
            <a href="../index.php" class="text-xs text-gray-400 hover:text-gray-600">Back to Website</a>
        </div>
    </div>

</body>
</html>