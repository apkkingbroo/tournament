<?php
include 'common/config.php';

// 1. Add Map/Category Column
$conn->query("ALTER TABLE tournaments ADD COLUMN map_type VARCHAR(50) DEFAULT 'Erangel/Classic'");

// 2. Add Square Icon Column
$conn->query("ALTER TABLE tournaments ADD COLUMN icon_url VARCHAR(255) DEFAULT NULL");

echo "<h1 style='color:green; background:black; padding:20px;'>✅ Database Updated: Added Map & Icon Features!</h1>";
echo "<a href='admin/tournament.php'>Go to Admin Panel</a>";
?>