<?php
include 'common/config.php';
if(!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); }
$uid = $_SESSION['user_id'];
$toast_msg = ""; 

// --- HANDLE DEPOSIT ---
if(isset($_POST['add_money'])) {
    $amount = abs(floatval($_POST['amount']));
    $utr = sanitize($conn, $_POST['utr']);
    if($amount > 0 && !empty($utr)) {
        $conn->query("INSERT INTO transactions (user_id, amount, type, description, proof_id, status, created_at) VALUES ($uid, $amount, 'credit', 'Deposit Request', '$utr', 'pending', NOW())");
        $toast_msg = "Deposit Request Submitted!";
    }
}

// --- HANDLE WITHDRAWAL (FIXED: Immediate Deduction) ---
if(isset($_POST['withdraw_money'])) {
    $amount = abs(floatval($_POST['w_amount']));
    $upi = sanitize($conn, $_POST['w_upi']);

    if($amount >= 50) {
        // 1. Check Balance
        $check = $conn->query("SELECT wallet_balance FROM users WHERE id=$uid");
        $cur_bal = $check->fetch_assoc()['wallet_balance'];

        if($cur_bal >= $amount) {
            $conn->begin_transaction();
            try {
                // 2. Deduct Immediately
                $conn->query("UPDATE users SET wallet_balance = wallet_balance - $amount WHERE id=$uid");
                
                // 3. Insert Record
                $stmt = $conn->prepare("INSERT INTO transactions (user_id, amount, type, description, proof_id, status, created_at) VALUES (?, ?, 'debit', 'Withdrawal', ?, 'pending', NOW())");
                $stmt->bind_param("ids", $uid, $amount, $upi);
                $stmt->execute();
                
                $conn->commit();
                $toast_msg = "Withdrawal Submitted & ₹$amount Deducted!";
            } catch(Exception $e) {
                $conn->rollback();
                $toast_msg = "Transaction Failed.";
            }
        } else {
             $toast_msg = "Insufficient Balance!";
        }
    } else {
        $toast_msg = "Minimum withdrawal is ₹50";
    }
}

// Fetch Fresh Data
$q = $conn->query("SELECT wallet_balance FROM users WHERE id = $uid");
$balance = $q->fetch_assoc()['wallet_balance'];
$tr = $conn->query("SELECT * FROM transactions WHERE user_id = $uid ORDER BY created_at DESC LIMIT 20");
$admin_upi = "bantikr@fam"; 
?>
<?php include 'common/header.php'; ?>

<!-- TOAST -->
<?php if($toast_msg): ?>
<div id="toast" class="fixed top-24 left-1/2 -translate-x-1/2 bg-gold-500 text-black px-6 py-3 rounded-full shadow-2xl z-[100] border border-white/20 flex items-center gap-2 animate-slide-up w-max max-w-[90%]">
    <i class="fa-solid fa-bell"></i>
    <span class="font-bold text-xs"><?php echo $toast_msg; ?></span>
</div>
<script>
    setTimeout(() => { document.getElementById('toast').remove(); }, 4000);
</script>
<style>
    @keyframes slideUp { from { transform: translate(-50%, -20px); opacity: 0; } to { transform: translate(-50%, 0); opacity: 1; } }
    .animate-slide-up { animation: slideUp 0.4s ease-out forwards; }
</style>
<?php endif; ?>

<div class="px-4 pt-4 pb-24">
    <!-- Balance Card -->
    <div class="bg-gradient-to-br from-dark-800 to-black p-6 rounded-2xl border border-gold-500/30 relative overflow-hidden shadow-[0_0_20px_rgba(234,179,8,0.1)] mb-6">
        <div class="absolute -right-6 -top-6 w-24 h-24 bg-gold-500/20 rounded-full blur-2xl"></div>
        <p class="text-gray-400 text-xs font-medium uppercase tracking-widest mb-1">Total Balance</p>
        <h2 class="text-4xl font-extrabold text-white">₹<?php echo number_format($balance, 2); ?></h2>
    </div>

    <!-- TABS -->
    <div class="flex gap-2 bg-dark-800 p-1 rounded-xl mb-6 border border-white/5">
        <button onclick="showTab('deposit')" id="btn-dep" class="flex-1 py-3 rounded-lg text-sm font-bold bg-gold-500 text-black transition-all shadow">ADD CASH</button>
        <button onclick="showTab('withdraw')" id="btn-wit" class="flex-1 py-3 rounded-lg text-sm font-bold text-gray-400 hover:text-white transition-all">WITHDRAW</button>
    </div>

    <!-- FORMS -->
    <div id="tab-deposit">
        <div class="bg-dark-800 p-4 rounded-xl border border-white/5 mb-6">
            <div class="bg-black p-3 rounded border border-dashed border-gray-600 text-center mb-4 flex items-center justify-between">
                <span class="text-gold-500 font-mono select-all text-sm"><?php echo $admin_upi; ?></span>
                <button class="text-xs text-blue-400">COPY</button>
            </div>
            <form method="POST" class="space-y-3">
                <input type="number" name="amount" placeholder="Amount (₹)" required class="w-full bg-black border border-gray-700 p-3 rounded-lg text-white focus:border-gold-500 outline-none">
                <input type="text" name="utr" placeholder="UTR / Ref No." required class="w-full bg-black border border-gray-700 p-3 rounded-lg text-white focus:border-gold-500 outline-none">
                <button type="submit" name="add_money" class="w-full bg-green-600 hover:bg-green-500 text-white font-bold py-3 rounded-lg transition">SUBMIT</button>
            </form>
        </div>
    </div>

    <div id="tab-withdraw" class="hidden">
         <div class="bg-dark-800 p-4 rounded-xl border border-white/5 mb-6">
            <p class="text-xs text-red-400 mb-4 text-center">Instant Balance Deduction. Min: ₹50</p>
            <form method="POST" class="space-y-3">
                <input type="number" name="w_amount" placeholder="Amount (Min ₹50)" required class="w-full bg-black border border-gray-700 p-3 rounded-lg text-white focus:border-red-500 outline-none">
                <input type="text" name="w_upi" placeholder="Your UPI ID" required class="w-full bg-black border border-gray-700 p-3 rounded-lg text-white focus:border-red-500 outline-none">
                <button type="submit" name="withdraw_money" class="w-full bg-red-600 hover:bg-red-500 text-white font-bold py-3 rounded-lg transition">WITHDRAW NOW</button>
            </form>
         </div>
    </div>
    
    <!-- HISTORY -->
    <h3 class="text-white font-bold mb-3">Transactions</h3>
    <div class="space-y-3">
        <?php while($row = $tr->fetch_assoc()): ?>
            <div class="flex justify-between items-center bg-dark-800 p-3 rounded-lg border border-white/5">
                <div class="flex items-center gap-3">
                    <div class="w-8 h-8 rounded-full flex items-center justify-center <?php echo ($row['type']=='credit')?'bg-green-500/10 text-green-500':'bg-red-500/10 text-red-500'; ?>">
                         <i class="fa-solid <?php echo ($row['type']=='credit')?'fa-arrow-down':'fa-arrow-up'; ?> text-xs"></i>
                    </div>
                    <div>
                        <p class="text-sm font-bold text-gray-200"><?php echo $row['description']; ?></p>
                        <p class="text-[10px] text-gray-500"><?php echo date("d M, h:i A", strtotime($row['created_at'])); ?></p>
                    </div>
                </div>
                <div class="text-right">
                    <p class="font-bold text-sm <?php echo ($row['type']=='credit')?'text-green-500':'text-red-500'; ?>">
                        <?php echo ($row['type']=='credit')?'+':'-'; ?> <?php echo $row['amount']; ?>
                    </p>
                    <span class="text-[10px] px-2 py-0.5 rounded bg-gray-700 text-gray-300"><?php echo $row['status']; ?></span>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
</div>

<script>
    function showTab(t) {
        document.getElementById('tab-deposit').classList.toggle('hidden', t !== 'deposit');
        document.getElementById('tab-withdraw').classList.toggle('hidden', t !== 'withdraw');
        document.getElementById('btn-dep').className = t === 'deposit' ? 'flex-1 py-3 rounded-lg text-sm font-bold bg-gold-500 text-black transition-all shadow' : 'flex-1 py-3 rounded-lg text-sm font-bold text-gray-400 hover:text-white transition-all';
        document.getElementById('btn-wit').className = t === 'withdraw' ? 'flex-1 py-3 rounded-lg text-sm font-bold bg-red-600 text-white transition-all shadow' : 'flex-1 py-3 rounded-lg text-sm font-bold text-gray-400 hover:text-white transition-all';
    }
</script>
<?php include 'common/bottom.php'; ?>