<?php
include 'common/config.php';

echo "<h2>🛠️ Repairing Database & User Table...</h2>";

// 1. Fix USERS Table (Ensure Email/Pass login works)
$conn->query("ALTER TABLE users MODIFY COLUMN email VARCHAR(100) NOT NULL UNIQUE");
$conn->query("ALTER TABLE users MODIFY COLUMN password VARCHAR(255) NOT NULL");
$conn->query("ALTER TABLE users MODIFY COLUMN username VARCHAR(50) NOT NULL");
// Make phone optional since we are using Email now
$conn->query("ALTER TABLE users MODIFY COLUMN phone VARCHAR(20) NULL");

// 2. Fix TRANSACTIONS Table (Fix Admin Dashboard Crash)
// Ensure 'status' column exists for the queries
$check = $conn->query("SHOW COLUMNS FROM transactions LIKE 'status'");
if($check->num_rows == 0) {
    $conn->query("ALTER TABLE transactions ADD COLUMN status ENUM('pending', 'success', 'failed') DEFAULT 'success'");
    echo "✅ Added 'status' to transactions.<br>";
}

// 3. Fix TOURNAMENTS Table
$check = $conn->query("SHOW COLUMNS FROM tournaments LIKE 'max_players'");
if($check->num_rows == 0) {
    $conn->query("ALTER TABLE tournaments ADD COLUMN max_players INT DEFAULT 100");
    echo "✅ Added 'max_players' to tournaments.<br>";
}

echo "<h3>✅ Database Repaired! <a href='login.php'>Go to Login</a> | <a href='admin/index.php'>Go to Admin</a></h3>";
?>