<?php 
$cur = basename($_SERVER['PHP_SELF']); 
?>
<?php if($cur !== 'login.php' && $cur !== 'install.php'): ?>
<div class="fixed bottom-0 w-full z-50">
    <!-- Gradient Line Top -->
    <div class="h-px w-full bg-gradient-to-r from-transparent via-gold-500/50 to-transparent"></div>
    
    <div class="bg-[#0a0a0a]/95 backdrop-blur-md pb-safe pt-2 px-6 flex justify-between items-center h-16 shadow-[0_-10px_40px_rgba(0,0,0,0.8)]">
        
        <a href="index.php" class="relative flex flex-col items-center group w-12">
            <div class="absolute -top-6 w-8 h-8 bg-gold-500/20 rounded-full blur-lg opacity-0 <?php echo ($cur=='index.php')?'opacity-100':''; ?> transition-opacity"></div>
            <i class="fa-solid fa-house text-xl mb-1 transition-all duration-300 <?php echo ($cur=='index.php')?'text-gold-500 -translate-y-1':'text-gray-500 group-hover:text-gray-300'; ?>"></i>
            <span class="text-[10px] font-medium <?php echo ($cur=='index.php')?'text-white':'text-gray-600'; ?>">Home</span>
        </a>

        <a href="my_tournaments.php" class="relative flex flex-col items-center group w-12">
            <div class="absolute -top-6 w-8 h-8 bg-gold-500/20 rounded-full blur-lg opacity-0 <?php echo ($cur=='my_tournaments.php')?'opacity-100':''; ?> transition-opacity"></div>
            <i class="fa-solid fa-trophy text-xl mb-1 transition-all duration-300 <?php echo ($cur=='my_tournaments.php')?'text-gold-500 -translate-y-1':'text-gray-500 group-hover:text-gray-300'; ?>"></i>
            <span class="text-[10px] font-medium <?php echo ($cur=='my_tournaments.php')?'text-white':'text-gray-600'; ?>">My Match</span>
        </a>

        <!-- Floating Action Button (Optional Center) -->
        <!-- <div class="w-12 h-12 bg-gold-500 rounded-full -mt-8 flex items-center justify-center shadow-lg border-4 border-black">
            <i class="fa-solid fa-plus text-black text-xl"></i>
        </div> -->

        <a href="wallet.php" class="relative flex flex-col items-center group w-12">
            <div class="absolute -top-6 w-8 h-8 bg-gold-500/20 rounded-full blur-lg opacity-0 <?php echo ($cur=='wallet.php')?'opacity-100':''; ?> transition-opacity"></div>
            <i class="fa-solid fa-wallet text-xl mb-1 transition-all duration-300 <?php echo ($cur=='wallet.php')?'text-gold-500 -translate-y-1':'text-gray-500 group-hover:text-gray-300'; ?>"></i>
            <span class="text-[10px] font-medium <?php echo ($cur=='wallet.php')?'text-white':'text-gray-600'; ?>">Wallet</span>
        </a>

        <a href="profile.php" class="relative flex flex-col items-center group w-12">
            <div class="absolute -top-6 w-8 h-8 bg-gold-500/20 rounded-full blur-lg opacity-0 <?php echo ($cur=='profile.php')?'opacity-100':''; ?> transition-opacity"></div>
            <i class="fa-solid fa-user text-xl mb-1 transition-all duration-300 <?php echo ($cur=='profile.php')?'text-gold-500 -translate-y-1':'text-gray-500 group-hover:text-gray-300'; ?>"></i>
            <span class="text-[10px] font-medium <?php echo ($cur=='profile.php')?'text-white':'text-gray-600'; ?>">Profile</span>
        </a>

    </div>
</div>
<?php endif; ?>
</body>
</html>