<?php
// Set Session Timeout to 30 Days
ini_set('session.gc_maxlifetime', 2592000);
session_set_cookie_params(2592000);

$host = "127.0.0.1";
$user = "root";
$pass = "root"; 
$db   = "banty_king_db";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    if (strpos($_SERVER['SCRIPT_NAME'], 'install.php') === false) {
        die("Connection failed: " . $conn->connect_error);
    }
}

// Global Settings
date_default_timezone_set('Asia/Kolkata');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function sanitize($conn, $input) {
    return mysqli_real_escape_string($conn, htmlspecialchars(strip_tags(trim($input))));
}
?>