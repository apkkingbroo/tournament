<?php
if(!isset($conn)) { 
    if(file_exists(__DIR__ . '/config.php')) {
        include __DIR__ . '/config.php';
    } else {
        // Fallback for admin pages
        include __DIR__ . '/../../common/config.php';
    }
}

$current_page = basename($_SERVER['PHP_SELF']);
$user_balance = 0;
// Default Avatar
$avatar = "https://api.dicebear.com/7.x/avataaars/svg?seed=Felix"; 

if(isset($_SESSION['user_id'])) {
    $uid = intval($_SESSION['user_id']);
    
    // SAFE QUERY: Selects all columns to prevent 'column not found' crashes
    $q = $conn->query("SELECT * FROM users WHERE id = $uid");
    
    // Safety Check: Only fetch if query succeeded
    if($q && $q->num_rows > 0) {
        $r = $q->fetch_assoc();
        
        // Safely access balance
        if(isset($r['wallet_balance'])) {
            $user_balance = $r['wallet_balance'];
        }
        
        // Safely access avatar
        if(isset($r['avatar']) && !empty($r['avatar'])) {
            $avatar = $r['avatar'];
        }
    } else {
        // If user ID in session doesn't exist in DB (e.g. DB reset), logout
        session_destroy();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Banty King</title>
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700;800&display=swap" rel="stylesheet">
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: { sans: ['Poppins', 'sans-serif'] },
                    colors: {
                        gold: { 400: '#FACC15', 500: '#EAB308', 600: '#CA8A04' },
                        dark: { 800: '#121212', 900: '#0a0a0a' }
                    },
                    animation: { 'float': 'float 3s ease-in-out infinite' },
                    keyframes: {
                        float: { '0%, 100%': { transform: 'translateY(0)' }, '50%': { transform: 'translateY(-5px)' } }
                    }
                }
            }
        }
    </script>
    <style>
        body { background-color: #050505; color: white; -webkit-tap-highlight-color: transparent; }
        .glass { background: rgba(18, 18, 18, 0.85); backdrop-filter: blur(12px); -webkit-backdrop-filter: blur(12px); }
    </style>
</head>
<body class="font-sans antialiased pb-24 select-none">

<?php if($current_page !== 'login.php' && $current_page !== 'install.php' && $current_page !== 'fix_db_final.php'): ?>
<nav class="fixed top-0 w-full z-50 glass border-b border-white/5 transition-all duration-300">
    <div class="px-4 py-3 flex justify-between items-center">
        <div class="flex items-center gap-3">
            <?php if(isset($_SESSION['user_id'])): ?>
                <a href="profile.php" class="relative group">
                    <img src="<?php echo $avatar; ?>" class="w-10 h-10 rounded-full border-2 border-gold-500 object-cover bg-gray-800">
                    <span class="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-black rounded-full"></span>
                </a>
            <?php else: ?>
                <i class="fa-solid fa-crown text-gold-500 text-2xl animate-float"></i>
            <?php endif; ?>
            
            <div>
                <h1 class="text-lg font-extrabold tracking-wide uppercase leading-none">Banty<span class="text-gold-500">King</span></h1>
            </div>
        </div>
        
        <div class="flex items-center gap-3">
            <a href="https://telegram.me/banty99057" class="w-8 h-8 rounded-full bg-blue-600/20 text-blue-400 flex items-center justify-center border border-blue-500/30">
                <i class="fa-brands fa-telegram"></i>
            </a>

            <?php if(isset($_SESSION['user_id'])): ?>
            <a href="wallet.php" class="bg-gradient-to-r from-gray-900 to-black px-3 py-1.5 rounded-full border border-gold-600/30 flex items-center gap-2 shadow-lg">
                <i class="fa-solid fa-wallet text-gold-400 text-xs"></i>
                <span class="font-bold text-sm text-white">₹<?php echo number_format($user_balance, 0); ?></span>
            </a>
            <?php endif; ?>
        </div>
    </div>
</nav>
<div class="h-20"></div>
<?php endif; ?>