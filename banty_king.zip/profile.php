<?php
include 'common/config.php';
if(!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); }
$uid = $_SESSION['user_id'];

$msg = "";
$user_q = $conn->query("SELECT * FROM users WHERE id = $uid");
$user = $user_q->fetch_assoc();

// Update Avatar
if(isset($_GET['set_avatar'])) {
    $seed = $_GET['set_avatar'];
    $avatar_url = "https://api.dicebear.com/7.x/avataaars/svg?seed=" . $seed;
    $conn->query("UPDATE users SET avatar='$avatar_url' WHERE id=$uid");
    header("Location: profile.php"); exit();
}

if(isset($_POST['update_profile'])) {
    $email = sanitize($conn, $_POST['email']);
    $conn->query("UPDATE users SET email='$email' WHERE id=$uid");
    $msg = "<p class='text-green-500 text-sm mb-2'>Profile Updated</p>";
    $user['email'] = $email;
}

if(isset($_POST['change_password'])) {
    $pass = $_POST['password'];
    $hash = password_hash($pass, PASSWORD_DEFAULT);
    $conn->query("UPDATE users SET password='$hash' WHERE id=$uid");
    $msg = "<p class='text-green-500 text-sm mb-2'>Password Changed</p>";
}

if(isset($_POST['logout'])) {
    session_destroy();
    header("Location: login.php"); exit();
}

$current_avatar = $user['avatar'] ? $user['avatar'] : 'https://api.dicebear.com/7.x/avataaars/svg?seed=Felix';
?>
<?php include 'common/header.php'; ?>

<div class="p-4 mb-20">
    <div class="text-center mb-6 mt-4">
        <!-- Current Avatar -->
        <div class="relative w-24 h-24 mx-auto mb-3">
            <img src="<?php echo $current_avatar; ?>" class="w-full h-full rounded-full border-4 border-yellow-500 bg-gray-800 shadow-xl">
            <div class="absolute bottom-0 right-0 bg-gray-800 p-2 rounded-full border border-gray-600 cursor-pointer" onclick="document.getElementById('avatar-selector').classList.toggle('hidden')">
                <i class="fa-solid fa-camera text-white text-xs"></i>
            </div>
        </div>
        
        <h2 class="text-xl font-bold text-white"><?php echo htmlspecialchars($user['username']); ?></h2>
        <p class="text-gray-400 text-sm">ID: <?php echo $user['id']; ?></p>
    </div>

    <!-- Avatar Selector (Hidden by default) -->
    <div id="avatar-selector" class="hidden bg-gray-800 p-4 rounded-xl mb-6 border border-gray-700 animate-fade-in">
        <p class="text-gray-400 text-xs mb-3 text-center">CHOOSE YOUR AVATAR</p>
        <div class="grid grid-cols-4 gap-3">
            <?php 
            $seeds = ['Felix', 'Aneka', 'Zoe', 'Jack', 'Trouble', 'Cuddles', 'Max', 'Rocky'];
            foreach($seeds as $s): 
                $url = "https://api.dicebear.com/7.x/avataaars/svg?seed=" . $s;
            ?>
                <a href="?set_avatar=<?php echo $s; ?>" class="block rounded-full overflow-hidden border-2 <?php echo (strpos($current_avatar, $s)!==false)?'border-green-500':'border-gray-600'; ?> hover:border-yellow-500 transition">
                    <img src="<?php echo $url; ?>" class="w-full h-full bg-gray-700">
                </a>
            <?php endforeach; ?>
        </div>
    </div>

    <?php echo $msg; ?>

    <div class="bg-gray-800 rounded-xl p-5 mb-4 border border-gray-700">
        <h3 class="text-gray-300 font-bold mb-4 border-b border-gray-700 pb-2">Edit Details</h3>
        <form method="POST" class="space-y-3">
            <div>
                <label class="block text-gray-500 text-xs mb-1">Email</label>
                <input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" class="w-full bg-gray-900 border border-gray-700 p-2 rounded text-white text-sm">
            </div>
            <button type="submit" name="update_profile" class="bg-blue-600 text-white text-xs py-2 px-4 rounded">Save Email</button>
        </form>
    </div>

    <div class="bg-gray-800 rounded-xl p-5 mb-6 border border-gray-700">
        <h3 class="text-gray-300 font-bold mb-4 border-b border-gray-700 pb-2">Security</h3>
        <form method="POST" class="space-y-3">
            <div>
                <label class="block text-gray-500 text-xs mb-1">New Password</label>
                <input type="password" name="password" placeholder="******" class="w-full bg-gray-900 border border-gray-700 p-2 rounded text-white text-sm">
            </div>
            <button type="submit" name="change_password" class="bg-gray-600 text-white text-xs py-2 px-4 rounded">Update Password</button>
        </form>
    </div>

    <form method="POST">
        <button type="submit" name="logout" class="w-full bg-red-600/20 text-red-500 border border-red-600/50 py-3 rounded-lg font-bold hover:bg-red-600/30 transition">
            <i class="fa-solid fa-right-from-bracket mr-2"></i> LOGOUT
        </button>
    </form>
</div>

<?php include 'common/bottom.php'; ?>