<?php
$host = "127.0.0.1";
$user = "root";
$pass = "root"; // Change if needed

$conn = new mysqli($host, $user, $pass);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

// Create Database
$sql = "CREATE DATABASE IF NOT EXISTS banty_king_db";
if ($conn->query($sql) === TRUE) {
    echo "Database created successfully.<br>";
} else {
    die("Error creating database: " . $conn->error);
}

$conn->select_db("banty_king_db");

// Users Table
$sql = "CREATE TABLE IF NOT EXISTS users (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL,
    password VARCHAR(255) NOT NULL,
    wallet_balance DECIMAL(10,2) DEFAULT 0.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";
$conn->query($sql);

// Admin Table
$sql = "CREATE TABLE IF NOT EXISTS admin (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
)";
$conn->query($sql);

// Insert Default Admin (admin / admin123)
$pass = password_hash("admin123", PASSWORD_DEFAULT);
$sql = "INSERT IGNORE INTO admin (username, password) VALUES ('admin', '$pass')";
$conn->query($sql);

// Tournaments Table
$sql = "CREATE TABLE IF NOT EXISTS tournaments (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    game_name VARCHAR(100) NOT NULL,
    entry_fee DECIMAL(10,2) NOT NULL,
    prize_pool DECIMAL(10,2) NOT NULL,
    match_time DATETIME NOT NULL,
    room_id VARCHAR(50) DEFAULT NULL,
    room_password VARCHAR(50) DEFAULT NULL,
    status ENUM('upcoming', 'live', 'completed') DEFAULT 'upcoming',
    winner_id INT(11) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";
$conn->query($sql);

// Participants Table
$sql = "CREATE TABLE IF NOT EXISTS participants (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    user_id INT(11) NOT NULL,
    tournament_id INT(11) NOT NULL,
    UNIQUE(user_id, tournament_id)
)";
$conn->query($sql);

// Transactions Table
$sql = "CREATE TABLE IF NOT EXISTS transactions (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    user_id INT(11) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    type ENUM('credit', 'debit') NOT NULL,
    description VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";
$conn->query($sql);

echo "Installation Complete. <a href='login.php'>Go to Login</a>";
?>