<?php
include 'common/config.php';

// Redirect if already logged in
if(isset($_SESSION['user_id'])) { header("Location: index.php"); exit(); }

$msg = "";

// --- LOGIN LOGIC ---
if(isset($_POST['login'])) {
    $email = sanitize($conn, $_POST['email']);
    $password = $_POST['password'];
    
    $stmt = $conn->prepare("SELECT id, username, password FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $res = $stmt->get_result();
    
    if($res->num_rows > 0) {
        $row = $res->fetch_assoc();
        if(password_verify($password, $row['password'])) {
            // Set Session Variables
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['username'] = $row['username'];
            
            // Redirect
            header("Location: index.php"); exit();
        } else {
            $msg = "Incorrect Password!";
        }
    } else {
        $msg = "Account not found with this email.";
    }
}

// --- SIGNUP LOGIC ---
if(isset($_POST['signup'])) {
    $user = sanitize($conn, $_POST['reg_user']);
    $email = sanitize($conn, $_POST['reg_email']);
    $pass = $_POST['reg_pass'];

    // 1. Check if email already exists
    $check = $conn->query("SELECT id FROM users WHERE email='$email'");
    if($check->num_rows > 0) {
        $msg = "Email already registered! Please Login.";
    } else {
        // 2. Hash Password
        $hash = password_hash($pass, PASSWORD_DEFAULT);
        
        // 3. Insert User
        $stmt = $conn->prepare("INSERT INTO users (username, email, password, wallet_balance) VALUES (?, ?, ?, 0.00)");
        $stmt->bind_param("sss", $user, $email, $hash);
        
        if($stmt->execute()) {
            $msg = "<span class='text-green-400'>Account Created! Please Login now.</span>";
        } else {
            $msg = "Error creating account.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Banty King - Login</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-black min-h-screen flex items-center justify-center relative overflow-hidden font-sans">
    
    <!-- Gold Ambient Glow -->
    <div class="absolute top-[-10%] left-[-10%] w-96 h-96 bg-yellow-600/20 rounded-full blur-[100px]"></div>
    <div class="absolute bottom-[-10%] right-[-10%] w-96 h-96 bg-yellow-600/10 rounded-full blur-[100px]"></div>

    <div class="w-full max-w-md p-8 relative z-10 backdrop-blur-md bg-gray-900/60 border border-gray-800 rounded-2xl shadow-[0_0_40px_rgba(0,0,0,0.8)]">
        
        <div class="text-center mb-8">
            <div class="inline-block p-4 rounded-full border border-yellow-500/30 bg-black/50 mb-4 shadow-[0_0_15px_rgba(234,179,8,0.2)]">
                <i class="fa-solid fa-crown text-4xl text-yellow-500"></i>
            </div>
            <h1 class="text-3xl font-bold text-white tracking-wider uppercase">Banty King</h1>
            <p class="text-yellow-500/60 text-xs tracking-[0.2em] uppercase mt-1">Luxury Gaming Platform</p>
        </div>

        <?php if($msg): ?>
            <div class="bg-red-900/30 border border-red-500/30 text-white text-sm p-3 rounded mb-6 text-center shadow-lg backdrop-blur animate-pulse">
                <?php echo $msg; ?>
            </div>
        <?php endif; ?>

        <!-- Tabs -->
        <div class="flex mb-6 bg-black/40 rounded-lg p-1 border border-gray-800">
            <button type="button" onclick="toggleTab('login')" id="btn-login" class="flex-1 py-2 text-sm font-bold rounded text-black bg-gradient-to-r from-yellow-400 to-yellow-600 transition shadow">LOGIN</button>
            <button type="button" onclick="toggleTab('signup')" id="btn-signup" class="flex-1 py-2 text-sm font-bold rounded text-gray-400 hover:text-white transition">SIGN UP</button>
        </div>

        <!-- Login Form -->
        <form method="POST" id="form-login" class="space-y-5">
            <div class="group">
                <input type="email" name="email" placeholder="Email Address" required class="w-full bg-black/50 border border-gray-700 text-white px-4 py-3 rounded-lg focus:outline-none focus:border-yellow-500 transition">
            </div>
            <div class="group">
                <input type="password" name="password" placeholder="Password" required class="w-full bg-black/50 border border-gray-700 text-white px-4 py-3 rounded-lg focus:outline-none focus:border-yellow-500 transition">
            </div>
            <button type="submit" name="login" class="w-full bg-gradient-to-r from-yellow-500 via-yellow-400 to-yellow-600 text-black font-extrabold py-3 rounded-lg shadow-lg hover:shadow-yellow-500/50 transition uppercase tracking-wide">
                Access Account
            </button>
        </form>

        <!-- Signup Form -->
        <form method="POST" id="form-signup" class="space-y-5 hidden">
            <input type="text" name="reg_user" placeholder="Username" required class="w-full bg-black/50 border border-gray-700 text-white px-4 py-3 rounded-lg focus:border-yellow-500 focus:outline-none transition">
            <input type="email" name="reg_email" placeholder="Email Address" required class="w-full bg-black/50 border border-gray-700 text-white px-4 py-3 rounded-lg focus:border-yellow-500 focus:outline-none transition">
            <input type="password" name="reg_pass" placeholder="Create Password" required class="w-full bg-black/50 border border-gray-700 text-white px-4 py-3 rounded-lg focus:border-yellow-500 focus:outline-none transition">
            <button type="submit" name="signup" class="w-full bg-gray-800 border border-yellow-500/50 text-yellow-500 font-bold py-3 rounded-lg hover:bg-yellow-500 hover:text-black transition uppercase tracking-wide shadow-lg">
                Create Account
            </button>
        </form>

    </div>

<script>
    function toggleTab(tab) {
        const loginForm = document.getElementById('form-login');
        const signupForm = document.getElementById('form-signup');
        const btnLogin = document.getElementById('btn-login');
        const btnSignup = document.getElementById('btn-signup');

        if(tab === 'login') {
            loginForm.classList.remove('hidden');
            signupForm.classList.add('hidden');
            btnLogin.className = "flex-1 py-2 text-sm font-bold rounded text-black bg-gradient-to-r from-yellow-400 to-yellow-600 transition shadow";
            btnSignup.className = "flex-1 py-2 text-sm font-bold rounded text-gray-400 hover:text-white transition";
        } else {
            loginForm.classList.add('hidden');
            signupForm.classList.remove('hidden');
            btnSignup.className = "flex-1 py-2 text-sm font-bold rounded text-black bg-gradient-to-r from-yellow-400 to-yellow-600 transition shadow";
            btnLogin.className = "flex-1 py-2 text-sm font-bold rounded text-gray-400 hover:text-white transition";
        }
    }
</script>
</body>
</html>