<?php
include 'common/config.php';
// Add phone column if not exists
$conn->query("ALTER TABLE users ADD COLUMN phone VARCHAR(15) UNIQUE DEFAULT NULL");
// Make username optional or use phone as username
$conn->query("ALTER TABLE users MODIFY COLUMN username VARCHAR(50) NULL");
$conn->query("ALTER TABLE users MODIFY COLUMN email VARCHAR(100) NULL");
$conn->query("ALTER TABLE users MODIFY COLUMN password VARCHAR(255) NULL"); // Password optional for OTP login

echo "Database Updated for Phone Login!";
?>