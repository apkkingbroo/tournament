<?php
include 'common/config.php';

// 1. Ensure Email/Password columns exist (Revert from Phone)
$conn->query("ALTER TABLE users MODIFY COLUMN email VARCHAR(100) NOT NULL");
$conn->query("ALTER TABLE users MODIFY COLUMN password VARCHAR(255) NOT NULL");
$conn->query("ALTER TABLE users MODIFY COLUMN username VARCHAR(50) NOT NULL");

// 2. Add Max Players for Progress Bar feature
$conn->query("ALTER TABLE tournaments ADD COLUMN max_players INT DEFAULT 100");

// 3. Add Screenshot column for User Result Uploads
$conn->query("ALTER TABLE participants ADD COLUMN result_screenshot VARCHAR(255) DEFAULT NULL");

echo "<h1 style='color:gold; background:black; padding:20px;'>✅ Database Updated for Luxury Features!</h1>";
echo "<a href='index.php'>Go Home</a>";
?>