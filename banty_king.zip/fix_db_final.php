<?php
$host = "127.0.0.1";
$user = "root";
$pass = "root"; // Check your password
$db   = "banty_king_db";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error); }

echo "<h2>🔧 Fixing Database...</h2>";

// 1. Ensure 'avatar' column exists in 'users'
$check = $conn->query("SHOW COLUMNS FROM users LIKE 'avatar'");
if($check->num_rows == 0) {
    $conn->query("ALTER TABLE users ADD COLUMN avatar VARCHAR(255) DEFAULT NULL");
    echo "✅ Added 'avatar' column.<br>";
}

// 2. Ensure 'wallet_balance' exists (just in case)
$check = $conn->query("SHOW COLUMNS FROM users LIKE 'wallet_balance'");
if($check->num_rows == 0) {
    $conn->query("ALTER TABLE users ADD COLUMN wallet_balance DECIMAL(10,2) DEFAULT 0.00");
    echo "✅ Added 'wallet_balance' column.<br>";
}

echo "<h3>🎉 Database Fixed! You can now Login without errors.</h3>";
echo "<a href='index.php'>Go Home</a>";
?>