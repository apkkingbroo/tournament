<?php
include 'common/config.php';
if(!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); }
$uid = $_SESSION['user_id'];
$msg = "";

if(isset($_POST['join_tournament'])) {
    $tid = intval($_POST['tournament_id']);
    $fee = floatval($_POST['entry_fee']);
    
    $check = $conn->query("SELECT * FROM participants WHERE user_id=$uid AND tournament_id=$tid");
    if($check->num_rows > 0) $msg = "Already Joined!";
    else {
        $bal = $conn->query("SELECT wallet_balance FROM users WHERE id=$uid")->fetch_assoc()['wallet_balance'];
        if($bal >= $fee) {
            $conn->query("UPDATE users SET wallet_balance = wallet_balance - $fee WHERE id=$uid");
            $conn->query("INSERT INTO transactions (user_id, amount, type, description, status) VALUES ($uid, $fee, 'debit', 'Joined #$tid', 'success')");
            $conn->query("INSERT INTO participants (user_id, tournament_id) VALUES ($uid, $tid)");
            $msg = "Success!";
            header("Refresh:0");
        } else { $msg = "Insufficient Balance"; }
    }
}

$sql = "SELECT * FROM tournaments WHERE status = 'upcoming' ORDER BY match_time ASC";
$result = $conn->query($sql);
?>
<?php include 'common/header.php'; ?>

<!-- TOAST -->
<?php if($msg): ?>
<div class="fixed top-24 left-1/2 -translate-x-1/2 bg-gold-500 text-black px-6 py-2 rounded-full shadow-xl z-[60] font-bold text-sm animate-bounce">
    <?php echo $msg; ?>
</div>
<?php endif; ?>

<div class="px-4 pt-4 pb-24">
    <!-- HERO SECTION -->
    <div class="bg-gradient-to-r from-gold-600 to-yellow-500 rounded-2xl p-5 mb-6 text-black relative overflow-hidden shadow-lg animate-slide-up">
        <div class="relative z-10">
            <h2 class="font-extrabold text-2xl mb-1">Play & Earn</h2>
            <p class="text-sm font-medium opacity-80 mb-3">Daily matches with huge prize pools.</p>
            <a href="wallet.php" class="bg-black text-white px-5 py-2 rounded-lg text-xs font-bold uppercase tracking-wider inline-block">Add Money</a>
        </div>
    </div>

    <!-- CARDS -->
    <div class="space-y-6">
        <?php while($row = $result->fetch_assoc()): ?>
            <?php 
                $tid = $row['id'];
                $total_slots = $row['max_players'] ? $row['max_players'] : 100;
                $filled = $conn->query("SELECT count(*) as c FROM participants WHERE tournament_id=$tid")->fetch_assoc()['c'];
                $percent = ($filled / $total_slots) * 100;
                
                // Banner
                $img = !empty($row['image_url']) ? $row['image_url'] : 'https://placehold.co/600x300/222/gold?text=Game';
                
                // Icon (Fallback to placeholder if empty)
                $icon = !empty($row['icon_url']) ? $row['icon_url'] : 'https://cdn-icons-png.flaticon.com/512/808/808439.png';
                
                // Map
                $map = !empty($row['map_type']) ? $row['map_type'] : 'Classic';
            ?>
            <div class="bg-dark-800 rounded-2xl border border-white/5 overflow-hidden relative animate-slide-up hover:border-gold-500/30 transition shadow-lg">
                
                <!-- Banner Image -->
                <div class="h-44 bg-cover bg-top relative" style="background-image: url('<?php echo $img; ?>');">
                    <div class="absolute inset-0 bg-gradient-to-t from-dark-800 via-transparent to-transparent"></div>
                    
                    <!-- Map/Category Badge -->
                    <div class="absolute top-3 right-3">
                         <span class="bg-black/60 backdrop-blur text-gold-500 text-[10px] font-bold px-3 py-1 rounded-full border border-gold-500/30 uppercase tracking-wide">
                            <?php echo $map; ?>
                         </span>
                    </div>

                    <!-- Square Icon Overlay -->
                    <div class="absolute -bottom-6 left-4">
                        <img src="<?php echo $icon; ?>" class="w-14 h-14 rounded-xl border-2 border-dark-800 shadow-xl bg-gray-800 object-cover">
                    </div>
                </div>

                <!-- Content -->
                <div class="p-4 pt-8">
                    <div class="flex justify-between items-start mb-2">
                        <div>
                            <h3 class="text-white font-bold text-lg leading-tight"><?php echo htmlspecialchars($row['title']); ?></h3>
                            <p class="text-gray-400 text-xs mt-1">
                                <i class="fa-regular fa-clock text-gold-500"></i> <?php echo date("d M, h:i A", strtotime($row['match_time'])); ?>
                            </p>
                        </div>
                        <div class="text-right">
                             <div class="bg-green-500/10 border border-green-500/30 px-2 py-1 rounded">
                                <p class="text-[10px] text-green-400 uppercase font-bold">Prize Pool</p>
                                <p class="text-green-400 font-bold">₹<?php echo $row['prize_pool']; ?></p>
                             </div>
                        </div>
                    </div>

                    <!-- Progress -->
                    <div class="flex justify-between text-[10px] text-gray-500 mb-1 mt-4">
                        <span>Slots</span>
                        <span class="text-white"><?php echo $filled; ?>/<?php echo $total_slots; ?></span>
                    </div>
                    <div class="w-full bg-gray-700 h-1.5 rounded-full overflow-hidden mb-4">
                        <div class="bg-gold-500 h-full rounded-full" style="width: <?php echo $percent; ?>%"></div>
                    </div>

                    <!-- Action -->
                    <?php if($filled >= $total_slots): ?>
                        <button class="w-full bg-gray-700 text-gray-400 py-3 rounded-xl font-bold text-sm cursor-not-allowed uppercase">Sold Out</button>
                    <?php else: ?>
                        <form method="POST">
                            <input type="hidden" name="tournament_id" value="<?php echo $row['id']; ?>">
                            <input type="hidden" name="entry_fee" value="<?php echo $row['entry_fee']; ?>">
                            <button type="submit" name="join_tournament" class="w-full bg-gradient-to-r from-gold-600 to-gold-500 text-black py-3 rounded-xl font-bold text-sm shadow-[0_5px_15px_rgba(234,179,8,0.3)] hover:shadow-gold-500/50 transition uppercase tracking-widest">
                                Join - ₹<?php echo $row['entry_fee']; ?>
                            </button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
</div>
<?php include 'common/bottom.php'; ?>